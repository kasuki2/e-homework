
var langHun = {};
langHun.belepve = "Belépve:";
langHun.ujhazi = "ÚJ HÁZI";
langHun.beadott = "BEADOTT HÁZI";
langHun.kijav = "KIJAVÍTOTT HÁZI";
langHun.beadom = "BEADOM ELLENŐRZÉSRE";


var langEng = {};
langEng.belepve = "Hi,:";
langEng.ujhazi = "NEW HOMEWORK";
langEng.beadott = "SUBMITTED HW";
langEng.kijav = "CORRECTED HW";
langEng.beadom = "SUBMIT THIS TASK";