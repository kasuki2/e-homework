<?php

// XAMPP:
//$TEACHER_LOGIN = "http://localhost:8080/ehw/TEACHER/teacherlogin.php";

 //$TEACHER_FIRST = "http://localhost:8080/ehw/TEACHER/correcthomework.php";



// HOME VAGRANT
$TEACHER_LOGIN = "teacherlogin.php";

$TEACHER_FIRST = "correcthomework.php";

?>
