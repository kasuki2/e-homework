<?php
/**
 * Created by PhpStorm.
 * User: telaw
 * Date: 2018. 03. 17.
 * Time: 13:08
 */

class BigFrame {
    public $title;
    public $instructions;
    public $weight;
    public $exa; // examples, some html?
    public $type;
    public $helps; // array for helping documents, but only for grammar
    public $contents; // array of arrays of OneItem

}