<?php
/**
 * Created by PhpStorm.
 * User: telaw
 * Date: 2018. 03. 31.
 * Time: 12:53
 */

class OneHomework {
    public $id;
    public $apath;
    public $atitle;
    public $userTipps;
    public $correct;
    public $date1;
    public $tipus;
    public $viewed;
    public $remarks; // only at type 2
    public $message;
    public $redo; // if student ask for a redo
    public $perf; // perfect hw?
}